import React from 'react';
import {connect} from 'react-redux';
import actions from '../actions';
import {getNearestDateIndex} from '../utils';

const DateSlider = React.createClass({
  componentWillMount: function () {
    // Set initial image display date
    this.setImageDisplayDate(this.props.displayDateIndex);
  },

  handleOnChange: function (indexMax, e) {
    // Set polygon display date index
    const displayDateIndex = indexMax - e.target.value;
    this.props.setDisplayDateIndex(displayDateIndex);
    // Set imagery display date
    this.setImageDisplayDate(displayDateIndex);
  },

  setImageDisplayDate: function (displayDateIndex) {
    const imageList = this.props.ndviImages;
    const imageDates = imageList.map((i) => i.date);
    const displayDate = this.props.fieldData.features[0]
                          .properties.ndvi_values[displayDateIndex].date;
    // Get the image data nearest to the polygon date slider date value
    const nearestImageDateIndex = getNearestDateIndex(imageDates, displayDate);
    const nearestImageDateId = imageList[nearestImageDateIndex].map_id;
    // Set the image date value to the date nearest to the polygon date slider
    this.props.setImageDisplayDateIndex(nearestImageDateIndex);
    this.props.setImageDisplayId(nearestImageDateId);
  },

  render: function () {
    const ndviDates = this.props.fieldData.features[0].properties.ndvi_values;
    const indexMax = ndviDates.length - 1;
    const latestDateLabel = ndviDates[0].date;
    const earliestDateLabel = ndviDates[ndviDates.length - 1].date;
    const displayDateIndex = this.props.displayDateIndex;
    const activeDateLabel = ndviDates[displayDateIndex].date;
    return (
      <div id='date-range' className='blurrable'>
        <input id='date-range-slider'
         name='slider'
         type='range'
         min='0'
         max={indexMax}
         step='1'
         value={indexMax - displayDateIndex}
         onChange={this.handleOnChange.bind(null, indexMax)}>
        </input>
        <div>
          <label id='date-range-early-label'>{earliestDateLabel}</label>
          <label id='date-range-late-label'>{latestDateLabel}</label>
          <label id='date-range-current-label'><span className='highlight-title'>Current: </span>{activeDateLabel}</label>
        </div>
      </div>
    );
  }
});

function mapStateToProps (state) {
  return {
    fieldData: state.fieldData,
    ndviImages: state.ndviImages,
    displayDateIndex: state.displayDateIndex,
    imageDisplayDateIndex: state.imageDisplayDateIndex
  };
}

function mapDispatchToProps (dispatch) {
  return {
    setDisplayDateIndex: function (index) {
      dispatch(actions.setDisplayDateIndex(index));
    },
    setImageDisplayDateIndex: function (index) {
      dispatch(actions.setImageDisplayDateIndex(index));
    },
    setImageDisplayId: function (id) {
      dispatch(actions.setImageDisplayId(id));
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(DateSlider);
