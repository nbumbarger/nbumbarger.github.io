import React from 'react';
import {connect} from 'react-redux';
import {FoundationApi} from 'react-foundation-apps';
import outside from 'react-onclickoutside';
import actions from '../actions';
import NdviImageMap from './NdviImageMap';
import NdviImageDateSlider from './NdviImageDateSlider';
import Graph from './Graph';
import MetadataBar from './MetadataBar';

const ModalContents = React.createClass({

  mixins: [outside],

  handleClickOutside: function (e) {
    FoundationApi.publish('field-detail-modal', 'close');
    if (e.target.parentNode.getAttribute('data-js') !== 'table-item') {
      setTimeout(function () {
        this.unblurBackground();
        this.props.setSelectedField(null);
      }.bind(this), 100);
    }
  },

  componentWillReceiveProps: function (nextProps) {
    if (nextProps.selectedField) {
      FoundationApi.publish('field-detail-modal', 'open');
      if (nextProps.selectedField !== this.props.selectedField) {
        this.blurBackground();
      }
    }
  },

  blurBackground: function () {
    const bgElements = document.getElementsByClassName('blurrable');
    for (let i = 0; i < bgElements.length; ++i) {
      bgElements[i].classList.add('blurred');
    }
  },

  unblurBackground: function () {
    const bgElements = document.querySelectorAll('.blurred');
    for (let i = 0; i < bgElements.length; ++i) {
      bgElements[i].classList.remove('blurred');
    }
  },

  handleTextInput: function (e) {
    let newDetails = {};
    newDetails[this.props.selectedField] = e.target.value;
    this.props.setFieldDetails(newDetails);
  },

  render: function () {
    const fieldData = this.props.fieldData;
    const selectedField = this.props.selectedField;

    const ndviImageMap = (selectedField)
      ? <NdviImageMap
          fieldData={fieldData}
          selectedField={selectedField}
          imageDisplayId={this.props.imageDisplayId}/>
      : '';

    const graph = (selectedField)
      ? <Graph
          fieldData={fieldData}
          selectedField={selectedField}
          ndviImages={this.props.ndviImages}
          imageDisplayDateIndex={this.props.imageDisplayDateIndex} />
      : '';

    return (
      <div>
        <MetadataBar
          fieldData={fieldData}
          selectedField={selectedField} />
        <div className='grid-frame'>
          <div className='grid-block'>
            <div className='grid-block medium-6 small-12 modal-interior left'>
              <NdviImageDateSlider
                ndviImages={this.props.ndviImages}
                imageDisplayDateIndex={this.props.imageDisplayDateIndex}
                imageDisplayId={this.props.imageDisplayId} />
              {ndviImageMap}
            </div>
            <div className='grid-block medium-6 small-0 modal-interior right'>
              <div className='graph-container'>
                {graph}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
});

function mapStateToProps (state) {
  return {
    fieldData: state.fieldData,
    selectedField: state.selectedField,
    ndviImages: state.ndviImages,
    imageDisplayDateIndex: state.imageDisplayDateIndex,
    imageDisplayId: state.imageDisplayId,
    displayDateIndex: state.displayDateIndex
  };
}

function mapDispatchToProps (dispatch) {
  return {
    setSelectedField: function (id) {
      dispatch(actions.setSelectedField(id));
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ModalContents);
