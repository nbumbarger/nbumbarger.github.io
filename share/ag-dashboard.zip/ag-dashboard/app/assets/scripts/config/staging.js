'use strict';
/*
 * App config overrides for staging.
 */

module.exports = {
  environment: 'staging'
};
