import _ from 'lodash';

function rootReducer (state, action) {
  // console.log(action);
  var newState = Object.assign({}, state);
  switch (action.type) {
    case 'SET_SELECTED_FIELD':
      newState.selectedField = action.data;
      break;
    case 'SET_SELECTED_TAB':
      newState.selectedTab = action.data;
      break;
    case 'SET_HOVERED_FIELD':
      newState.hoveredField = action.data;
      break;
    case 'SET_FIELD_SORT_STATE':
      newState.sortState = action.data;
      break;
    case 'SET_FIELD_DISPLAY_DATE_INDEX':
      newState.displayDateIndex = action.data;
      break;
    case 'SET_IMAGE_DISPLAY_DATE_INDEX':
      newState.imageDisplayDateIndex = action.data;
      break;
    case 'SET_IMAGE_DISPLAY_ID':
      newState.imageDisplayId = action.data;
      break;
    case 'SET_FIELD_DETAILS':
      const stateCopy = _.cloneDeep(newState);
      const fieldId = Object.keys(action.data)[0];
      let fieldDetails = stateCopy.fieldDetails;
      fieldDetails[fieldId] = action.data[fieldId];
      newState.fieldDetails = fieldDetails;
      break;
    default:
      console.warn('Undefined action: ' + action.type);
      return state;
  }
  return newState;
}
export default rootReducer;
