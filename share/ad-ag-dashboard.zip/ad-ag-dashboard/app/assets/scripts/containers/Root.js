import React from 'react';
import {createStore} from 'redux';
import {Provider} from 'react-redux';
import reducer from '../reducer';
import App from './App';
import fieldData from '../../data/fields.json';
import ndviImages from '../../data/ndvi_images.json';

/* Manually set default date index */
const displayDateIndex = 10;

/** STORE **/
const initialState = {
  fieldData,
  ndviImages,
  selectedField: null,
  hoveredField: null,
  sortState: {
    field: 'ndviChange',
    order: 'asc'
  },
  displayDateIndex: displayDateIndex,
  imageDisplayDateIndex: 8,
  imageDisplayId: ndviImages[0].map_id,
  fieldDetails: {},
  selectedTab: 'summary'
};

const store = createStore(reducer, initialState);

/** ROOT OBJECT **/
export default React.createClass({
  render: function () {
    return (
      <Provider store={store}>
        <App />
      </Provider>
    );
  }
});
