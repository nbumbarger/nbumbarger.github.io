import React from 'react';
import {connect} from 'react-redux';
import actions from '../actions';
import {getNearestDateIndex} from '../utils';

const ImageDateSlider = React.createClass({
  handleOnChange: function (indexMax, dates, e) {
    // Set imagery display date
    const imageDisplayDateIndex = indexMax - e.target.value;
    this.props.setImageDisplayDateIndex(imageDisplayDateIndex);
    this.props.setImageDisplayId(dates[imageDisplayDateIndex].map_id);
    // Set polygon display date
    this.setMainDisplayDate(imageDisplayDateIndex);
  },

  setMainDisplayDate: function (imageDisplayDateIndex) {
    const fieldList = this.props.fieldData.features.find((field) => {
      return field.properties.field_id === this.props.selectedField;
    }).properties.ndvi_values;
    const fieldDates = fieldList.map((field) => field.date);
    const imageDisplayDate = this.props.ndviImages[imageDisplayDateIndex].date;
    // Get the field data nearest to the image date slider date value
    const nearestFieldDateIndex = getNearestDateIndex(fieldDates, imageDisplayDate);
    // Set the main field date value to the date nearest to the imagery date slider
    this.props.setDisplayDateIndex(nearestFieldDateIndex);
  },

  render: function () {
    const dates = this.props.ndviImages;
    const indexMax = dates.length - 1;
    const latestDateLabel = dates[0].date;
    const earliestDateLabel = dates[dates.length - 1].date;
    const activeDateLabel = dates[this.props.imageDisplayDateIndex].date;
    return (
      <div className='date-range-bottom' id='date-range'>
        <input id='date-range-slider'
         name='slider'
         type='range'
         min='0'
         max={indexMax}
         step='1'
         value={indexMax - this.props.imageDisplayDateIndex}
         onChange={this.handleOnChange.bind(null, indexMax, dates)}>
        </input>
        <div>
          <label id='date-range-early-label'>{earliestDateLabel}</label>
          <label id='date-range-late-label'>{latestDateLabel}</label>
          <label id='date-range-current-label'><span className='highlight-title'>Current:</span> {activeDateLabel}</label>
        </div>
      </div>
    );
  }
});

function mapStateToProps (state) {
  return {
    fieldData: state.fieldData,
    selectedField: state.selectedField,
    imageDisplayDateIndex: state.imageDisplayDateIndex
  };
}

function mapDispatchToProps (dispatch) {
  return {
    setDisplayDateIndex: function (index) {
      dispatch(actions.setDisplayDateIndex(index));
    },
    setImageDisplayDateIndex: function (index) {
      dispatch(actions.setImageDisplayDateIndex(index));
    },
    setImageDisplayId: function (id) {
      dispatch(actions.setImageDisplayId(id));
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(ImageDateSlider);
