import React from 'react';
import L from 'leaflet';
import {connect} from 'react-redux';
import actions from '../actions';
const accessToken = 'pk.eyJ1IjoiYXN0cm9kaWdpdGFsIiwiYSI6ImNVb1B0ZkEifQ.IrJoULY2VMSBNFqHLrFYew';
const thresholdNDVIValue = -0.08; // Value under which to call out fields

const MainMap = React.createClass({
  componentDidMount: function () {
    this.setupMap(this.props.fieldData);
  },

  setSymbology: function (
    layer, displayDateIndex, outlineWeight, fillColorBoost, outlineColor) {
    const colormap = this.props.colormap;
    let ndviVal = Math.floor(layer.feature.properties.ndvi_values[displayDateIndex].value * 255);
    // Boost NDVI value for display purposes
    ndviVal = Math.floor(Math.min((ndviVal * 0.9 + 10), 255));
    const [r, g, b] = colormap[ndviVal].map((color) => Math.min(color + fillColorBoost, 255));
    const symbology = {
      color: `rgb(${r + 50},${g + 50},${b + 50})`,
      weight: outlineWeight,
      opacity: 1,
      fillOpacity: 0.8,
      fillColor: `rgb(${r},${g},${b})`
    };
    if (outlineColor) symbology.color = outlineColor;

    layer.setStyle(symbology);
  },

  componentWillReceiveProps: function (nextProps) {
    const features = nextProps.fieldData.features;
    const displayDateIndex = nextProps.displayDateIndex;
    const hoveredFieldId = nextProps.hoveredField;
    const selectedFieldId = nextProps.selectedField;
    // Zoom to field if new field ID not equal to previous field ID
    if (selectedFieldId && selectedFieldId !== this.props.selectedField) {
      // Find the field object containing the selected field ID
      const selectedField = features.reduce(function (prev, curr) {
        return (curr.properties.field_id === selectedFieldId) ? curr : prev;
      }, null);
      const lon = selectedField.properties.center_lon;
      const lat = selectedField.properties.center_lat;
      this.map.setView([lat, lon], 14);
    }

    // Set layer active
    const component = this;
    this.farmLayer.eachLayer(function (layer) {
      if (layer.feature.properties.field_id === selectedFieldId) {
        component.setSymbology(layer, displayDateIndex, 4, 0, '#C2DC16');
      } else if (layer.feature.properties.field_id === hoveredFieldId) {
        component.setSymbology(layer, displayDateIndex, 4, 40, '#1b9bff');
      } else {
        let weight = 1;
        let color;
        const diff = component._generateDiff(layer.feature.properties.ndvi_values, displayDateIndex);
        if (diff < thresholdNDVIValue) {
          weight = 4;
          color = 'white';
        }
        component.setSymbology(layer, displayDateIndex, weight, 0, color);
      }
    });
  },

  _generateDiff: function (values, index) {
    const prevDateIndex = index + 1;
    let diff;
    if (prevDateIndex < values.length) {
      diff = values[index].value - values[prevDateIndex].value;
    }

    return diff;
  },

  onEachFeature: function (feature, layer) {
    let weight = 1;
    let color;
    const diff = this._generateDiff(feature.properties.ndvi_values, this.props.displayDateIndex);
    if (diff < thresholdNDVIValue) {
      weight = 4;
      color = 'white';
    }
    this.setSymbology(layer, this.props.displayDateIndex, weight, 0, color);
    layer
      .on('click', (e) => {
        this.props.setSelectedField(feature.properties.field_id);
      })
      .on('mouseover', (e) => {
        if (this.props.selectedField !== e.target.feature.properties.field_id) {
          this.props.setHoveredField(feature.properties.field_id);
        }
      })
      .on('mouseout', (e) => {
        this.props.setHoveredField(null);
      });
  },

  setupMap: function (fieldData) {
    const basemapUrl = 'http://api.tiles.mapbox.com/v4/mapbox.satellite/{z}/{x}/{y}.png';

    this.map = L.map('map', {zoomControl: false}).setView([41.964208, -93.2331315], 13);
    new L.Control.Zoom({position: 'bottomleft'}).addTo(this.map);

    L.tileLayer(`${basemapUrl}?access_token=${accessToken}`, {
      attribution: '<a href="http://astrodigital.com">Astro Digital</a> | Imagery © <a href="http://mapbox.com">Mapbox</a>'
    })
    .addTo(this.map);

    this.farmLayer = L.geoJson(fieldData, {
      onEachFeature: this.onEachFeature
    })
    .addTo(this.map);
  },

  render: function () {
    return (
      <div id='map' className='blurrable'></div>
    );
  }
});

function mapStateToProps (state) {
  return {
    fieldData: state.fieldData,
    displayDateIndex: state.displayDateIndex,
    hoveredField: state.hoveredField,
    selectedField: state.selectedField
  };
}

function mapDispatchToProps (dispatch) {
  return {
    setHoveredField: function (id) {
      dispatch(actions.setHoveredField(id));
    },
    setSelectedField: function (id) {
      dispatch(actions.setSelectedField(id));
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MainMap);
