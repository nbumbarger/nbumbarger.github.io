import React from 'react';
import L from 'leaflet';
import _ from 'lodash';
const accessToken = 'pk.eyJ1IjoiYXN0cm9kaWdpdGFsIiwiYSI6ImNVb1B0ZkEifQ.IrJoULY2VMSBNFqHLrFYew';

const ImageBrowseMap = React.createClass({
  componentDidMount: function () {
    setTimeout(() => this.setupMap(), 50);
  },

  componentWillUnmount: function () {
    this.map.removeLayer(this.fieldLayer);
  },

  componentWillReceiveProps (nextProps) {
    const tileLayerUrl = `http://a.tiles.mapbox.com/v4/${nextProps.imageDisplayId}/{z}/{x}/{y}.png`;
    this.map.removeLayer(this.tileLayer);
    this.tileLayer = L.tileLayer(`${tileLayerUrl}?access_token=${accessToken}`, {
      attribution: '<a href="http://astrodigital.com">Astro Digital</a>'
    })
    .addTo(this.map);
  },

  setupMap: function () {
    const tileLayerUrl = `http://a.tiles.mapbox.com/v4/${this.props.imageDisplayId}/{z}/{x}/{y}.png`;
    const activeField = _.cloneDeep(this.props.fieldData.features.filter((field) => {
      return field.properties.field_id === this.props.selectedField;
    })[0]);

    this.map = L.map('image-browse-map', {attributionControl: false})
    .setView([
      activeField.properties.center_lat,
      activeField.properties.center_lon], 15);
    L.control.attribution({position: 'topright'}).addTo(this.map);

    this.tileLayer = L.tileLayer(`${tileLayerUrl}?access_token=${accessToken}`, {
      attribution: '<a href="http://astrodigital.com">Astro Digital</a>'
    })
    .addTo(this.map);

    // Transform active field boundaries to inner ring
    // of global boundaries, to create an inverse mask
    activeField.geometry.coordinates = [
      [
        [-180, -90],
        [-180, 90],
        [180, 90],
        [180, -90],
        [-180, -90]
      ],
      activeField.geometry.coordinates[0]
    ];

    this.fieldLayer = L.geoJson(activeField, {
      fillOpacity: 1,
      fillColor: '#000',
      weight: 0
    })
    .addTo(this.map);
  },

  render: function () {
    return (
      <div id='image-browse-map'>
      </div>
    );
  }
});

export default ImageBrowseMap;
