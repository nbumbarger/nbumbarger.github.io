import React from 'react';
import _ from 'lodash';
import classnames from 'classnames';
import {connect} from 'react-redux';
import actions from '../actions';
const thresholdNDVIValue = 0; // Value under which to call out fields

const displayHeader = [
  {key: 'fieldid', value: 'Field ID'},
  {key: 'ndviChange', value: 'NDVI' + String.fromCharCode(916)},
  {key: 'ndvi', value: 'NDVI'}
];

const SideNav = React.createClass({
  sortLinkClickHandler: function (field, e) {
    e.preventDefault();
    let {field: sortField, order: sortOrder} = this.props.sortState;
    let order = 'asc';
    // Same field, switch order; different field, reset order.
    if (sortField === field) {
      order = sortOrder === 'asc' ? 'desc' : 'asc';
    }
    this.props.setSortState({
      field,
      order
    });
  },

  renderTableHead: function () {
    return (
      <thead>
        <tr>
          {_.map(displayHeader, (o) => {
            let c = classnames('sort-header', {
              'collecticon-sort-none': this.props.sortState.field !== o.key,
              'collecticon-sort-asc': this.props.sortState.field === o.key && this.props.sortState.order === 'asc',
              'collecticon-sort-desc': this.props.sortState.field === o.key && this.props.sortState.order === 'desc'
            });
            return (
              <th key={o.key} onClick={this.sortLinkClickHandler.bind(null, o.key)}>
              <a href=''>{o.value}</a>
              <span className={c}></span>
              </th>
            );
          })}
        </tr>
      </thead>
    );
  },

  renderTableBody: function () {
    const displayDateIndex = this.props.displayDateIndex;

    const fieldData = this.props.fieldData.features.map(function (field) {
      const fieldProps = field.properties;
      const ndviValues = fieldProps.ndvi_values;
      const prevDateIndex = displayDateIndex + 1;
      const activeNdvi = ndviValues[displayDateIndex].value;

      let prevNdvi = 0;
      let ndviChange = 'N/A';
      if (prevDateIndex < ndviValues.length) {
        prevNdvi = (ndviValues[prevDateIndex].value);
        ndviChange = activeNdvi - prevNdvi;
      }
      return {fieldid: fieldProps.field_id, ndviChange: ndviChange, ndvi: activeNdvi};
    });

    let sorted = _(fieldData).sortBy(this.props.sortState.field);
    if (this.props.sortState.order === 'desc') {
      sorted = sorted.reverse();
    }
    sorted = sorted.value();

    return (
      <tbody>
      {_.map(sorted, (o, i) => {
        const c = classnames({
          'item-selected': o.fieldid === this.props.selectedField,
          'item-highlighted': o.fieldid === this.props.hoveredField,
          'item-threshold': o.ndviChange < thresholdNDVIValue
        });
        return (
          <tr
            key={`tr-${o.fieldid}`}
            className={c}
            data-js='table-item'
            onClick={this.handleFieldClick.bind(null, o.fieldid)}
            onMouseOver= {this.handleFieldHover.bind(null, o.fieldid)}>
          {_.map(displayHeader, (d) => {
            let key = d.key;
            let rowVal = o[key];
            // Convert displayed NDVI values to right-padded strings
            if (key !== 'fieldid' && rowVal !== 'N/A') rowVal = rowVal.toFixed(3);
            return (
              <td key={`tr-${i}-td-${key}`}>{rowVal}</td>
            );
          })}
          </tr>
        );
      })}
      </tbody>
    );
  },

  changeTab: function (e) {
    this.props.setSelectedTab(e.target.id);
  },

  getTotalArea: function () {
    let totalArea = 0;
    this.props.fieldData.features.forEach((f) => {
      totalArea += f.properties.area_m;
    });

    return totalArea / 10000; // Convert to hectares
  },

  // Mocking for now, based on selected date
  getFieldRanges: function () {
    const day = new Date(this.props.fieldData.features[0].properties.ndvi_values[this.props.displayDateIndex].date).getDay();
    const inRange = 80 + day;
    const outOfRange = 100 - inRange;
    return {inRange, outOfRange};
  },

  render: function () {
    const ranges = this.getFieldRanges();
    const body = this.props.selectedTab === 'details'
    ? (
      <table className='field-list'>
        {this.renderTableHead()}
        {this.renderTableBody()}
      </table>
    )
    : (
      <div className='summary'>
        <div className='summary-area'>
          <div className='summary-header'>Fields Overview</div>
          <hr />
          <div className='fields-box'>
            <span className='summary-number'>{ranges.outOfRange}%</span>
            <span className='summary-text'>out of range</span>
          </div>
          <div className='vertical-hr'><span className='divider'></span></div>
          <div className='fields-box'>
            <span className='summary-number'>{ranges.inRange}%</span>
            <span className='summary-text'>in range</span>
          </div>
        </div>
        <div className='summary-area'>
          <div className='summary-header'>Monthly Rainfall Overview</div>
          <hr />
          <div className='precip-box'>
            <span className='summary-number'>1.3 in</span>
            <span className='summary-text'>2014</span>
          </div>
          <div className='precip-box'>
            <span className='summary-number'>1.7 in</span>
            <span className='summary-text'>2015</span>
          </div>
          <div className='precip-box'>
            <span className='summary-number'>1.1 in</span>
            <span className='summary-text'>2016</span>
          </div>
        </div>
        <div className='summary-area'>
          <div className='summary-header'>Acreage Overview</div>
          <hr />
          <div className='fields-box'>
            <span className='summary-number'>{this.props.fieldData.features.length.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</span>
            <span className='summary-text'>fields</span>
          </div>
          <div className='vertical-hr'><span className='divider'></span></div>
          <div className='fields-box'>
            <span className='summary-number'>{this.getTotalArea().toFixed().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</span>
            <span className='summary-text'>hectares</span>
          </div>
        </div>
      </div>
    );

    return (
      <div className='my-tabs'>
        <div className='tab-header'>
          <div className={classnames('tab-item', {'is-active': this.props.selectedTab === 'summary'})} onClick={this.changeTab} id='summary'>Summary</div>
          <div className={classnames('tab-item', {'is-active': this.props.selectedTab === 'details'})} onClick={this.changeTab} id='details'>Details</div>
        </div>
        <div className='tab-body'>
          {body}
        </div>
      </div>
    );
  },

  handleFieldHover: function (id) {
    this.props.setHoveredField(id);
  },

  handleFieldClick: function (id) {
    this.props.setSelectedField(id);
  }

});

function mapStateToProps (state) {
  return {
    fieldData: state.fieldData,
    sortState: state.sortState,
    hoveredField: state.hoveredField,
    selectedField: state.selectedField,
    displayDateIndex: state.displayDateIndex,
    selectedTab: state.selectedTab
  };
}

function mapDispatchToProps (dispatch) {
  return {
    setSortState: function (sortState) {
      dispatch(actions.setSortState(sortState));
    },
    setHoveredField: function (id) {
      dispatch(actions.setHoveredField(id));
    },
    setSelectedField: function (id) {
      dispatch(actions.setSelectedField(id));
    },
    setSelectedTab: function (data) {
      dispatch(actions.setSelectedTab(data));
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SideNav);
