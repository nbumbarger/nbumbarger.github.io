import React from 'react';
import {connect} from 'react-redux';
import actions from '../actions';

const MetadataBar = React.createClass({
  handleTextInput: function (e) {
    let newDetails = {};
    newDetails[this.props.selectedField] = e.target.value;
    this.props.setFieldDetails(newDetails);
  },

  render: function () {
    const selectedField = this.props.selectedField;
    const fieldDetails = this.props.fieldDetails;
    let fieldDetailString = fieldDetails[selectedField];
    if (typeof fieldDetailString === 'undefined') {
      fieldDetailString = 'Same crop as 2013, 2014, 2015';
    }

    const cropType = this.props.fieldData.cropType || 'White Corn';
    const soilType = this.props.fieldData.soilType || 'Copaston';

    let fieldAreaHa = 0;
    if (selectedField) {
      fieldAreaHa = (this.props.fieldData.features.filter((field) => {
        return field.properties.field_id === selectedField;
      })[0].properties.area_m / 10000).toFixed(2);
    }

    return (
      <ul className='header'>
        <li><span className='highlight-title'>Field ID:</span> {this.props.selectedField}</li>
        <li><span className='highlight-title'>Crop Type:</span> {cropType}</li>
        <li><span className='highlight-title'>Soil Type:</span> {soilType}</li>
        <li><span className='highlight-title'>Area:</span> {fieldAreaHa} ha</li>
        <li><span className='highlight-title'>Details:</span>
          <input type='text' value={fieldDetailString} onChange={this.handleTextInput} />
        </li>
      </ul>
    );
  }
});

function mapStateToProps (state) {
  return {
    fieldDetails: state.fieldDetails
  };
}

function mapDispatchToProps (dispatch) {
  return {
    setFieldDetails: function (fieldDetails) {
      dispatch(actions.setFieldDetails(fieldDetails));
    }
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MetadataBar);
