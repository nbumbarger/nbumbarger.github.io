# IFPRI IMPACT Model website

A narrative-driven site for sharing the results of IFPRI IMPACT model runs, which seek to consider the long term challenges facing policymakers in reducing hunger and poverty in a sustainable fashion.

## Note to Blue Raster
This work-in-progress publishing system transforms Markdown files with a particular metadata structure into a complete site, with topic filtering, sorting, and relationship exposure, in which individual articles are loaded on demand. The Markdown parser is able to generate several types of figures, including choropleth maps and graphs with interactive features.

Dummy Markdown files can be generated using the command
```
npm run generate
```
in order to test site generation, and the figure syntax can be live-tested at http://localhost:3000/#/previewer.

In its present form, this site assumes that figure attributes will be drawn from a particular database, and does a fair amount of work to translate and aggregate those attributes accordingly. Generalizing the system, as I mentioned in my work samples document, is going to require some careful thought into making data sources more flexible, but I think the foundation is there.

## Development environment
To set up the development environment for this website, you'll need to install the following on your system:

- Node (v6.x) & Npm ([nvm](https://github.com/creationix/nvm) usage is advised)

> The versions mentioned are the ones used during development. It could work with newer ones.

After these basic requirements are met, run the following commands in the website's folder:
```
$ npm install
```

### Getting started

```
$ npm run serve
```
or
```
$ gulp serve
```
Compiles the sass files, javascript, and launches the server making the site available at `http://localhost:3000/`
The system will watch files and execute tasks whenever one of them changes.
The site will automatically refresh since it is bundled with livereload.

### Other commands
Compile the sass files, javascript... Use this instead of ```gulp serve``` if you don't want to watch.
```
$ npm run build
```
or
```
$ gulp
```
