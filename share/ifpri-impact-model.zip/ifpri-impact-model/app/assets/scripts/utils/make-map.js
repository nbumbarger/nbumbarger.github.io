'use strict'

const makeMap = (data) => {
  return '## Map'
}

export default makeMap
