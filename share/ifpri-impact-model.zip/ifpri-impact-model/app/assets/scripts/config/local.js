'use strict'
module.exports = {
  environment: 'development',
  dbUrl: 'https://ad21a5a8cb0789e9b73c2142d3c83e43.us-east-1.aws.found.io:9243/ifpri',
  baseUrl: 'http://localhost:3000'
}
