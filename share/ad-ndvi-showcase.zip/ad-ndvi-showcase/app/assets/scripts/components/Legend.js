import React from 'react';
import {browserPrefix} from '../utils';

const Legend = React.createClass({
  buildLegend: function () {
    const colormap = this.props.colormap;
    // Develop legend from colormap file
    let gradientCss = '';
    Object.keys(colormap).splice(1).forEach(function (color, i) {
      const [r, g, b] = colormap[color];
      gradientCss += `, rgb(${r},${g},${b})`;
    });
    gradientCss = `(left${gradientCss})`;
    return (
      <div
        id = 'legend_gradient'
        style={{background: `-${browserPrefix()}-linear-gradient${gradientCss}`}}>
      </div>
    );
  },

  render: function () {
    return (
      <div id='legend'>
        <h4>NDVI Intensity Legend</h4>
        {this.buildLegend()}
        <label className={this.props.labelStyle + 'wide'}>Non-Vegetated</label>
        <label className={this.props.labelStyle + 'narrow'}>Low</label>
        <label className={this.props.labelStyle + 'narrow'}>Med</label>
        <label className={this.props.labelStyle + 'narrow'}>High</label>
      </div>
    );
  }
});

export default Legend;
