import React from 'react';
import Chart from 'chart.js';
import precipData from '../../data/precipitation.json';
import {getNearestDateIndex, getQueryVariable} from '../utils';

// Check for graph display preferences
const graphAverages = (getQueryVariable('graph') !== 'all');

// Returns a clone of a date object, does not mutate
function cloneDate (date) {
  return new Date(date.getTime());
}

// Returns a clone of the reversed array, does not mutate
function cloneReverse (arr) {
  return arr.slice().reverse();
}

// Returns the index of the date one year prior to the input
// date, rounded to a date that exists in the input array
function getPrevYearIndex (inputDate, dateArray) {
  const previousYearDate = new Date(cloneDate(inputDate).setFullYear(
                                    cloneDate(inputDate).getFullYear() - 1));
  return getNearestDateIndex(dateArray, previousYearDate);
}

// Takes a full array of ndvi values and one of corresponding dates,
// and calculates averages over years for a second array of dates
function getAverageNdvi (ndviDatesRecent, ndviDates, ndviValues) {
  var ndviValuesAvg = [];
  cloneReverse(ndviDatesRecent).forEach(function (date, i) {
    const prevYearIndex = getPrevYearIndex(new Date(date), ndviDates);
    const currentNdvi = cloneReverse(ndviValues)[i];
    const prevNdvi = ndviValues[prevYearIndex];
    ndviValuesAvg.unshift((currentNdvi + prevNdvi) / 2);
  });
  return ndviValuesAvg;
}

const Graph = React.createClass({
  markGraphDate: function (imageDisplayDateIndex) {
    // Get index of the graphed precipitation/ values product date which
    // is closest to the selected image date
    const imageDisplayDate = this.ndviImageDates[imageDisplayDateIndex];
    const nearestDateIndex = getNearestDateIndex(this.ndviDates, imageDisplayDate);

    // Highlight graph using nearest matching date
    this.graph.options.scales.xAxes[0].drawLineAtIndex = nearestDateIndex;
    let ndviPoint = this.graph.config.data.datasets[0].metaData[nearestDateIndex]._view;
    let avgPoint = this.graph.config.data.datasets[1].metaData[nearestDateIndex]._view;
    let precipPoint = this.graph.config.data.datasets[2].metaData[nearestDateIndex]._view;
    ndviPoint.radius = 12;
    avgPoint.radius = 12;
    precipPoint.radius = 12;

    this.graph.update();
  },

  componentWillReceiveProps: function (nextProps) {
    this.markGraphDate(nextProps.imageDisplayDateIndex);
  },

  componentDidMount: function () {
    const ndviData = this.props.fieldData.features.find((field) => {
      return field.properties.field_id === this.props.selectedField;
    }).properties.ndvi_values;

    this.ndviDates = ndviData.map((data) => data.date).reverse();
    this.ndviImageDates = this.props.ndviImages.map((data) => data.date);
    var ndviValues = ndviData.map((data) => data.value).reverse();
    var precipValues = precipData.map((data) => data.value).reverse();

    var graphData = {
      labels: this.ndviDates,
      datasets: [{
        label: 'NDVI',
        yAxisID: 'y-axis-1',
        data: ndviValues,
        fill: true,
        borderColor: 'rgba(119, 226, 24, 1)',
        backgroundColor: 'rgba(119, 226, 24, 0.2)',
        pointBackgroundColor: 'rgba(123, 255, 26, .8)',
        pointBorderColor: 'rgba(87, 197, 21, 1)',
        pointBorderWidth: 1,
        pointHoverRadius: 7
      }, {
        label: 'Precipitation (in)',
        yAxisID: 'y-axis-2',
        data: precipValues,
        fill: false,
        borderColor: 'rgba(27, 155, 255, 1)',
        pointBackgroundColor: 'rgba(27, 155, 255, .8)',
        pointBorderColor: 'rgba(20, 114, 197, 1)',
        pointBorderWidth: 1,
        pointHoverRadius: 7
      }]
    };

    var graphOptions = {
      responsive: true,
      maintainAspectRatio: false,
      tooltips: {
        caretSize: 0
      },
      hover: {
        mode: 'label'
      },
      title: {
        display: true,
        text: 'NDVI Response / Precipitation',
        fontFamily: 'Lato',
        fontColor: 'rgba(0,0,0,0.85)',
        fontSize: 15
      },
      legend: {
        display: true,
        fullWidth: false,
        labels: {
          fontFamily: 'Lato',
          fontStyle: 'bold',
          fontColor: 'rgba(0,0,0,0.75)'
        }
      },
      elements: {
        point: {
          radius: 0,
          hitRadius: 6
        }
      },
      scales: {
        xAxes: [{
          drawLineAtIndex: 0,
          position: 'bottom',
          ticks: {
            maxTicksLimit: 15,
            fontFamily: 'Lato',
            fontColor: 'rgba(0,0,0,0.5)'
          },
          gridLines: {
            display: false
          }
        }],
        yAxes: [{
          id: 'y-axis-1',
          scaleType: 'linear',
          display: true,
          position: 'left',
          ticks: {
            beginAtZero: true,
            max: 1,
            fontFamily: 'Lato',
            fontColor: 'rgba(0,0,0,0.5)'
          },
          gridLines: {
            show: true,
            color: 'rgba(0,0,0,0.15)',
            lineWidth: 1,
            drawOnChartArea: true,
            drawTicks: true,
            zeroLineWidth: 1,
            zeroLineColor: 'rgba(0,0,0,0.15)'
          }
        }, {
          id: 'y-axis-2',
          scaleType: 'linear',
          display: true,
          position: 'right',
          ticks: {
            beginAtZero: true,
            fontFamily: 'Lato',
            fontColor: 'rgba(0,0,0,0.5)'
          },
          gridLines: {
            show: true,
            color: 'rgba(0, 0, 0, 0.15)',
            lineWidth: 1,
            drawOnChartArea: false,
            drawTicks: true,
            zeroLineWidth: 1,
            zeroLineColor: 'rgba(0,0,0,0.15)'
          }
        }]
      }
    };

    // If the averaging feature is turned on, reduce graph range to one
    // year and calculate averages over time
    if (graphAverages === true) {
      // Get the index of the date closest to the most recent date
      // in the previous year
      const latestDate = new Date(this.ndviDates[this.ndviDates.length - 1]);
      const prevYearIndex = getPrevYearIndex(latestDate, this.ndviDates);

      // Reduce the dates and values arrays to the most recent year
      const ndviDatesRecent = this.ndviDates.slice(prevYearIndex - 1);

      // Calculate average NDVI value for each date in the recent dates array
      var ndviValuesAvg = getAverageNdvi(ndviDatesRecent, this.ndviDates, ndviValues);

      // After making use full dataset, overwrite it to most recent year only
      ndviValues = ndviValues.slice(prevYearIndex - 1);
      precipValues = precipValues.slice(prevYearIndex - 1);
      this.ndviDates = ndviDatesRecent;

      // Update the graph with past years' data and averaged dataset
      const avgGraphData = {
        label: 'NDVI Avg',
        yAxisID: 'y-axis-1',
        data: ndviValuesAvg,
        fill: false,
        borderColor: 'rgba(209, 0, 190, 1)',
        pointBackgroundColor: 'rgba(209, 0, 190, .8)',
        pointBorderColor: 'rgba(184, 0, 167, 1)',
        pointBorderWidth: 1,
        pointHoverRadius: 7
      };
      graphData.labels = this.ndviDates;
      graphData.datasets[0].data = ndviValues;
      graphData.datasets[1].data = precipValues;
      graphData.datasets.splice(1, 0, avgGraphData);
    }

    var ctx = document.getElementById('graph').getContext('2d');
    // SetTimeout fixes Safari bug, where chart would not display
    // if not visible when instantiated
    const component = this;
    setTimeout(function () {
      component.graph = new Chart(ctx, {
        type: 'line',
        data: graphData,
        options: graphOptions});
      component.markGraphDate(component.props.imageDisplayDateIndex);
    }, 0);
  },

  render: function () {
    return <canvas id='graph'></canvas>;
  }
});

module.exports = Graph;
