import React from 'react';
import {Modal} from 'react-foundation-apps';
import ModalContents from './ModalContents';

const ModalFrame = React.createClass({

  render: function () {
    return (
      <div>
        <Modal id='field-detail-modal' overlay={true}>
          <ModalContents />
        </Modal>
      </div>
    );
  }
});

export default ModalFrame;
