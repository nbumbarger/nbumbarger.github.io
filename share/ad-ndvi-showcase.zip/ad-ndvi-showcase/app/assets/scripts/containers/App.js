import React from 'react';
import _ from 'lodash';
import MainMap from '../components/MainMap';
import Legend from '../components/Legend';
import MainDateSlider from '../components/MainDateSlider';
import SideNav from '../components/SideNav';
import ModalFrame from '../components/ModalFrame';
import {getQueryVariable} from '../utils';
import legends from '../../data/legends.json';

// Check for legend color preferences
const legend = getQueryVariable('legend') || 'ndvi';
const colormap = legends[legend].colormap;
let legendColormap = colormap;

// In case of NDVI legend, truncate values and rearange labels
let labelStyle = '';
if (legend === 'ndvi') {
  labelStyle = 'ndvi-legend-';
  legendColormap = _.cloneDeep(colormap);
  for (let i = 0; i <= 100; i++) {
    delete legendColormap[i];
  }
}

const App = React.createClass({
  render: function () {
    return (
      <div className='grid-frame vertical'>
        <div className='grid-block shrink wrap header-links'>
          <div className='grid-content collapse small-12 medium-12 app-title'>
            <div className='menu-bar blurrable'>
              <img className='logo' src='assets/graphics/layout/ag-seed-logo.svg' />
              <span className='title'>AgSeed Field Exploration Tool</span>
            </div>
          </div>
        </div>
        <div className='grid-block'>
          <div className='grid-block medium-3 side-nav blurrable'>
            <SideNav />
          </div>
          <div className='grid-block medium-9 small-12'>
            <ModalFrame />
            <MainDateSlider />
            <Legend colormap={legendColormap} labelStyle={labelStyle}/>
            <MainMap colormap={colormap}/>
          </div>
        </div>
      </div>
    );
  }
});

export default App;
