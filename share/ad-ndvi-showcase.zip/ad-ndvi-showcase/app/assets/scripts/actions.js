module.exports = {
  setSelectedField: function (selected) {
    return {
      type: 'SET_SELECTED_FIELD',
      data: selected
    };
  },
  setSelectedTab: function (selected) {
    return {
      type: 'SET_SELECTED_TAB',
      data: selected
    };
  },
  setHoveredField: function (hovered) {
    return {
      type: 'SET_HOVERED_FIELD',
      data: hovered
    };
  },
  setSortState: function (sortState) {
    return {
      type: 'SET_FIELD_SORT_STATE',
      data: sortState
    };
  },
  setDisplayDateIndex: function (index) {
    return {
      type: 'SET_FIELD_DISPLAY_DATE_INDEX',
      data: index
    };
  },
  setImageDisplayDateIndex: function (index) {
    return {
      type: 'SET_IMAGE_DISPLAY_DATE_INDEX',
      data: index
    };
  },
  setImageDisplayId: function (id) {
    return {
      type: 'SET_IMAGE_DISPLAY_ID',
      data: id
    };
  },
  setFieldDetails: function (fieldDetails) {
    return {
      type: 'SET_FIELD_DETAILS',
      data: fieldDetails
    };
  }
};
