'use strict';

// Given an array of dates and a date, returns the index of the
// array date that is nearest to the input date
export function getNearestDateIndex (dateArray, targetDate) {
  const epochs = dateArray.map((date) => new Date(date).getTime());
  const nearestEpoch = dateArray.map((date) => new Date(date))
    .sort((a, b) => Math.abs(1 - a / new Date(targetDate)) -
                    Math.abs(1 - b / new Date(targetDate)))[0]
    .getTime();

  return epochs.indexOf(nearestEpoch);
}

// Returns the value of a query string from the url,
// or returns false if query string is not found
export function getQueryVariable (variable) {
  const query = window.location.search.substring(1);
  const vars = query.split('&');
  for (let i = 0; i < vars.length; i++) {
    const pair = vars[i].split('=');
    if (pair[0] === variable) {
      return pair[1];
    }
  }
  return false;
}

// Returns the web browser's vendor-specific css prefix
export function browserPrefix () {
  const styles = window.getComputedStyle(document.documentElement, '');
  const pre = (Array.prototype.slice
      .call(styles)
      .join('')
      .match(/-(moz|webkit|ms)-/) || (styles.OLink === '' && ['', 'o'])
    )[1];
  return pre;
}
